"""离线校验交付包的文件哈希、回答数量及导出一致性。"""
import csv
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent

def fp(value):
    text = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def file_hash(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

listed = set()
for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
    expected, name = line.split("  ", 1)
    assert name not in listed and ".." not in Path(name).parts
    listed.add(name)
    assert file_hash(root / name) == expected, "文件已改变：" + name

info = json.loads((root / "数据概况.json").read_text(encoding="utf-8"))
raw = {}
for model in info["模型"]:
    folder = root / "原始结果" / model["运行目录"]
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    manifest_hash = fp(manifest)
    count = 0
    for file in (folder / model["模型标识"]).rglob("*.json"):
        data = json.loads(file.read_text(encoding="utf-8"))
        assert data["manifest_hash"] == manifest_hash
        for record in data["records"]:
            key = "/".join([data["model"], data["benchmark"], data["prompt_id"], record["question_id"]])
            assert key not in raw
            raw[key] = fp(record)
            count += 1
    assert count == model["回答数"] == 18600

seen = set()
reviews = 0
with (root / "便于清洗/全部回答.jsonl").open(encoding="utf-8") as f:
    for line in f:
        row = json.loads(line)
        key = row["record_id"]
        assert key not in seen and raw[key] == row["record_hash"] == fp(row["record"])
        seen.add(key)
        reviews += int(row["included_in_review"])
assert len(raw) == len(seen) == info["总回答数"] == 74400
assert reviews == info["总待复核数"] == 3920
csv.field_size_limit(10 * 1024 * 1024)
for name, expected in [("全部回答.csv", 74400), ("待复核回答_请在副本填写.csv", 3920)]:
    with (root / "便于清洗" / name).open(encoding="utf-8-sig", newline="") as f:
        keys = [row["记录编号"] for row in csv.DictReader(f)]
    assert len(keys) == len(set(keys)) == expected
    assert set(keys).issubset(raw)
print("校验通过：4 个模型，74,400 条回答，3,920 条待复核；原始记录与 JSONL 一致。")
